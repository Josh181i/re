document.addEventListener('DOMContentLoaded', () => {
    const languageSelect = document.getElementById('language-select');
    let translations = {};

    async function loadTranslations() {
        try {
            const response = await fetch('../assets/js/languages.json');
            if (!response.ok) {
                console.error('Failed to load languages.json');
                return;
            }
            translations = await response.json();
            const savedLanguage = localStorage.getItem('language') || 'es';
            setLanguage(savedLanguage);
        } catch (error) {
            console.error('Error loading or parsing languages.json:', error);
        }
    }

    function setLanguage(lang) {
        localStorage.setItem('language', lang);
        languageSelect.value = lang;
        translatePage(lang);
    }

    function translatePage(lang) {
        if (!translations[lang]) {
            console.warn(`Translations for language "${lang}" not found.`);
            return;
        }
        document.querySelectorAll('[data-key]').forEach(element => {
            const key = element.getAttribute('data-key');
            if (translations[lang][key]) {
                // For elements with children, we need to be careful not to overwrite them
                // A simple approach is to replace only the text nodes
                const childNodes = Array.from(element.childNodes);
                const textNode = childNodes.find(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim().length > 0);
                if(textNode) {
                    textNode.textContent = translations[lang][key];
                } else {
                     element.textContent = translations[lang][key];
                }
            }
        });
    }

    languageSelect.addEventListener('change', (event) => {
        setLanguage(event.target.value);
    });

    loadTranslations();
});
