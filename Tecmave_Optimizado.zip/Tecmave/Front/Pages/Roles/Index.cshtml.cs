using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Front.Pages.Roles
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
